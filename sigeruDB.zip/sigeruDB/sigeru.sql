CREATE DATABASE IF NOT EXISTS sigeru
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sigeru;

CREATE TABLE zonas (
  id_zona INT AUTO_INCREMENT PRIMARY KEY,
  nombre_zona VARCHAR(100) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE usuarios (
  id_usuario INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  apellido VARCHAR(100) NOT NULL,
  ci VARCHAR(20) NOT NULL UNIQUE,
  telefono VARCHAR(20) NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  tipo_usuario ENUM('administrador', 'cuadrilla', 'operario', 'vecino') NOT NULL,
  estado ENUM('activo', 'pendiente', 'inactivo') NOT NULL DEFAULT 'pendiente',
  foto VARCHAR(255) NULL,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE sesiones (
  token VARCHAR(64) PRIMARY KEY,
  id_usuario INT NOT NULL,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  expira_en DATETIME NOT NULL,
  CONSTRAINT fk_sesion_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE codigos_funcionario (
  id_codigo INT AUTO_INCREMENT PRIMARY KEY,
  codigo VARCHAR(30) NOT NULL UNIQUE,
  tipo_usuario ENUM('administrador', 'cuadrilla', 'operario') NOT NULL,
  usado BOOLEAN NOT NULL DEFAULT FALSE,
  id_usuario INT NULL,
  creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_codigo_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario)
) ENGINE=InnoDB;

CREATE TABLE centros_acopio (
  id_centro INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  ubicacion VARCHAR(200) NOT NULL,
  capacidad DECIMAL(10,2) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE administradores (
  id_usuario INT PRIMARY KEY,
  CONSTRAINT fk_admin_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE cuadrillas (
  id_usuario INT PRIMARY KEY,
  CONSTRAINT fk_cuadrilla_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Operario: relación "trabaja_en" con Centro_Acopio (N:1)
CREATE TABLE operarios (
  id_usuario INT PRIMARY KEY,
  id_centro INT NOT NULL,
  CONSTRAINT fk_operario_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE,
  CONSTRAINT fk_operario_centro FOREIGN KEY (id_centro) REFERENCES centros_acopio(id_centro)
) ENGINE=InnoDB;

CREATE TABLE vecinos (
  id_usuario INT PRIMARY KEY,
  CONSTRAINT fk_vecino_usuario FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE recursos (
  id_recurso INT AUTO_INCREMENT,
  id_centro INT NOT NULL,
  tipo VARCHAR(100) NOT NULL,
  cantidad INT NOT NULL DEFAULT 0,
  PRIMARY KEY (id_centro, id_recurso),
  CONSTRAINT fk_recurso_centro FOREIGN KEY (id_centro) REFERENCES centros_acopio(id_centro) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE contenedores (
  id_contenedor INT AUTO_INCREMENT PRIMARY KEY,
  ubicacion VARCHAR(200) NOT NULL,
  estado ENUM('funcional', 'roto', 'desbordado') NOT NULL DEFAULT 'funcional',
  tipo_residuo VARCHAR(100) NOT NULL,
  id_zona INT NULL,
  latitud DECIMAL(10,7) NULL,
  longitud DECIMAL(10,7) NULL,
  CONSTRAINT fk_contenedor_zona FOREIGN KEY (id_zona) REFERENCES zonas(id_zona)
) ENGINE=InnoDB;

CREATE TABLE camiones (
  id_camion INT AUTO_INCREMENT PRIMARY KEY,
  matricula VARCHAR(20) NOT NULL UNIQUE,
  estado ENUM('disponible', 'en_ruta', 'mantenimiento', 'fuera_servicio') NOT NULL DEFAULT 'disponible'
) ENGINE=InnoDB;

CREATE TABLE incidencias (
  id_incidencia INT AUTO_INCREMENT PRIMARY KEY,
  tipo ENUM('rotura', 'desborde', 'falta_recoleccion', 'otro') NOT NULL,
  estado ENUM('abierta', 'en_curso', 'resuelta') NOT NULL DEFAULT 'abierta',
  fecha_apertura TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  fecha_resolucion TIMESTAMP NULL,
  id_contenedor INT NOT NULL,
  id_vecino INT NULL,
  id_cuadrilla INT NULL,
  CONSTRAINT fk_incidencia_contenedor FOREIGN KEY (id_contenedor) REFERENCES contenedores(id_contenedor),
  CONSTRAINT fk_incidencia_vecino FOREIGN KEY (id_vecino) REFERENCES vecinos(id_usuario),
  CONSTRAINT fk_incidencia_cuadrilla FOREIGN KEY (id_cuadrilla) REFERENCES cuadrillas(id_usuario)
) ENGINE=InnoDB;

CREATE TABLE rutas (
  id_ruta INT AUTO_INCREMENT PRIMARY KEY,
  fecha DATE NOT NULL,
  id_cuadrilla INT NULL,
  id_camion INT NULL,
  CONSTRAINT fk_ruta_cuadrilla FOREIGN KEY (id_cuadrilla) REFERENCES cuadrillas(id_usuario),
  CONSTRAINT fk_ruta_camion FOREIGN KEY (id_camion) REFERENCES camiones(id_camion)
) ENGINE=InnoDB;

CREATE TABLE ruta_contenedor (
  id_ruta INT NOT NULL,
  id_contenedor INT NOT NULL,
  orden INT NOT NULL,
  PRIMARY KEY (id_ruta, id_contenedor),
  CONSTRAINT fk_rc_ruta FOREIGN KEY (id_ruta) REFERENCES rutas(id_ruta) ON DELETE CASCADE,
  CONSTRAINT fk_rc_contenedor FOREIGN KEY (id_contenedor) REFERENCES contenedores(id_contenedor)
) ENGINE=InnoDB;

INSERT INTO zonas (nombre_zona) VALUES
  ('Buceo'), ('Malvín'), ('Cerro'), ('Casavalle');


INSERT INTO usuarios (nombre, apellido, ci, telefono, email, password_hash, tipo_usuario, estado) VALUES
  ('Admin', 'SiGeRU', '11111111', '099111111', 'admin@sigeru.uy', '$2y$10$92Ck2t8NlYQ6q7nQ0m0Zp.Y0h1u3G5zj1yQe0m2k3n4p5q6r7s8t9', 'administrador', 'activo');

INSERT INTO administradores (id_usuario) VALUES (1);

INSERT INTO codigos_funcionario (codigo, tipo_usuario) VALUES
  ('SIGERU-ADM-7F2K', 'administrador'),
  ('SIGERU-CUA-9X3M', 'cuadrilla'),
  ('SIGERU-OPE-4L8N', 'operario');

INSERT INTO centros_acopio (nombre, ubicacion, capacidad) VALUES
  ('Centro de Acopio Buceo', 'Rambla Rep. de México, Montevideo', 500.00),
  ('Vertedero Felipe Cardoso', 'Camino Felipe Cardoso, Montevideo', 5000.00);

INSERT INTO recursos (id_centro, tipo, cantidad) VALUES
  (1, 'Contenedores de repuesto', 10),
  (2, 'Palas cargadoras', 2);

INSERT INTO contenedores (ubicacion, estado, tipo_residuo, id_zona, latitud, longitud) VALUES
  ('Av. Italia y Rivera', 'funcional', 'Residuos comunes', 2, -34.8969, -56.1425),
  ('Bvar. Artigas y 8 de Octubre', 'desbordado', 'Reciclables', 1, -34.8988, -56.1613),
  ('Camino Maldonado km 15', 'roto', 'Residuos comunes', 4, -34.8562, -56.0801);

INSERT INTO camiones (matricula, estado) VALUES
  ('SBC 1234', 'disponible'),
  ('SBD 5678', 'en_ruta');
