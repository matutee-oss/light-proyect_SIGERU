/**
 * panel-vecino.js
 * Formulario simple para reportar un problema en un contenedor,
 * y listado de los reportes propios.
 */

const sesion = exigirSesion(['vecino']);

async function cargarContenedoresSelect() {
  const respuesta = await fetch(`${API_URL}/contenedores.php`);
  const contenedores = await respuesta.json();

  document.getElementById('id_contenedor').innerHTML = contenedores
    .map(c => `<option value="${c.id_contenedor}">${c.ubicacion}</option>`)
    .join('');
}

async function cargarMisReportes() {
  const respuesta = await fetchAutenticado(`${API_URL}/incidencias.php`);
  const reportes = await respuesta.json();
  const lista = document.getElementById('lista-reportes');
  lista.innerHTML = '';

  if (reportes.length === 0) {
    lista.innerHTML = '<p class="mono" style="color:var(--ink-faint); font-size:13px;">Todavía no reportaste nada.</p>';
    return;
  }

  reportes.forEach(function (r) {
    const item = document.createElement('div');
    item.className = 'tarjeta-item';
    item.innerHTML = `
      <div>
        <strong>${r.contenedor_ubicacion}</strong>
        <div class="mono" style="font-size:12px; color:var(--ink-soft); margin-top:2px;">${r.tipo}</div>
      </div>
      <span class="etiqueta-estado estado-${r.estado}">${r.estado}</span>
    `;
    lista.appendChild(item);
  });
}

document.getElementById('form-reporte').addEventListener('submit', async function (evento) {
  evento.preventDefault();

  const datos = {
    id_contenedor: document.getElementById('id_contenedor').value,
    tipo: document.getElementById('tipo').value
  };

  const divMensaje = document.getElementById('mensaje-reporte');

  try {
    const respuesta = await fetchAutenticado(`${API_URL}/incidencias.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos)
    });

    const resultado = await respuesta.json();

    if (respuesta.ok && resultado.exito) {
      divMensaje.innerHTML = `<div class="mensaje exito">${resultado.mensaje}</div>`;
      cargarMisReportes();
    } else {
      divMensaje.innerHTML = `<div class="mensaje error">${resultado.mensaje}</div>`;
    }
  } catch (error) {
    divMensaje.innerHTML = '<div class="mensaje error">Error de conexión con el servidor</div>';
    console.error(error);
  }
});

cargarContenedoresSelect();
cargarMisReportes();
