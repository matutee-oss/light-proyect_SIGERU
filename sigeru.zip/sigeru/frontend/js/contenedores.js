async function cargarContenedores() {
  const tabla = document.getElementById('tabla-contenedores');
  tabla.innerHTML = '<tr><td colspan="5">Cargando...</td></tr>';

  try {
    const respuesta = await fetch(`${API_URL}/contenedores.php`);
    const contenedores = await respuesta.json();

    tabla.innerHTML = '';
    contenedores.forEach(function (contenedor) {
      const fila = document.createElement('tr');
      fila.innerHTML = `
        <td>${contenedor.id_contenedor}</td>
        <td>${contenedor.ubicacion}</td>
        <td>${contenedor.tipo_residuo}</td>
        <td><span class="etiqueta-estado estado-${contenedor.estado}">${contenedor.estado}</span></td>
        <td><button data-id="${contenedor.id_contenedor}" class="btn-eliminar">Eliminar</button></td>
      `;
      tabla.appendChild(fila);
    });

    document.querySelectorAll('.btn-eliminar').forEach(function (boton) {
      boton.addEventListener('click', () => eliminarContenedor(boton.dataset.id));
    });
  } catch (error) {
    tabla.innerHTML = '<tr><td colspan="5">Error al cargar contenedores</td></tr>';
    console.error(error);
  }
}

async function eliminarContenedor(id) {
  if (!confirm('¿Eliminar este contenedor?')) return;

  await fetch(`${API_URL}/contenedores.php?id=${id}`, { method: 'DELETE' });
  cargarContenedores();
}

document.getElementById('form-contenedor').addEventListener('submit', async function (evento) {
  evento.preventDefault();

  const idZona = document.getElementById('id_zona').value;
  const datos = {
    ubicacion: document.getElementById('ubicacion').value,
    tipo_residuo: document.getElementById('tipo_residuo').value,
    estado: document.getElementById('estado').value,
    id_zona: idZona ? parseInt(idZona, 10) : null
  };

  const divMensaje = document.getElementById('mensaje-contenedor');

  try {
    const respuesta = await fetch(`${API_URL}/contenedores.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos)
    });

    const resultado = await respuesta.json();

    if (respuesta.ok && resultado.exito) {
      divMensaje.innerHTML = `<div class="mensaje exito">${resultado.mensaje}</div>`;
      document.getElementById('form-contenedor').reset();
      cargarContenedores();
    } else {
      divMensaje.innerHTML = `<div class="mensaje error">${resultado.mensaje}</div>`;
    }
  } catch (error) {
    divMensaje.innerHTML = `<div class="mensaje error">Error de conexión con el servidor</div>`;
    console.error(error);
  }
});

cargarContenedores();
