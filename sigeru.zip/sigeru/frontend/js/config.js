/**
 * config.js
 * URL base del backend. Cambiar según dónde esté desplegada la API.
 */

const API_URL = "http://localhost/sigeru/backend";
