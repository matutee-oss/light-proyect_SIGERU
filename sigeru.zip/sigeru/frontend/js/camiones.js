async function cargarCamiones() {
  const tabla = document.getElementById('tabla-camiones');
  tabla.innerHTML = '<tr><td colspan="4">Cargando...</td></tr>';

  try {
    const respuesta = await fetch(`${API_URL}/camiones.php`);
    const camiones = await respuesta.json();

    tabla.innerHTML = '';
    camiones.forEach(function (camion) {
      const fila = document.createElement('tr');
      fila.innerHTML = `
        <td>${camion.id_camion}</td>
        <td>${camion.matricula}</td>
        <td><span class="etiqueta-estado estado-${camion.estado}">${camion.estado}</span></td>
        <td><button data-id="${camion.id_camion}" class="btn-eliminar">Eliminar</button></td>
      `;
      tabla.appendChild(fila);
    });

    document.querySelectorAll('.btn-eliminar').forEach(function (boton) {
      boton.addEventListener('click', () => eliminarCamion(boton.dataset.id));
    });
  } catch (error) {
    tabla.innerHTML = '<tr><td colspan="4">Error al cargar camiones</td></tr>';
    console.error(error);
  }
}

async function eliminarCamion(id) {
  if (!confirm('¿Eliminar este camión?')) return;

  await fetch(`${API_URL}/camiones.php?id=${id}`, { method: 'DELETE' });
  cargarCamiones();
}

document.getElementById('form-camion').addEventListener('submit', async function (evento) {
  evento.preventDefault();

  const datos = {
    matricula: document.getElementById('matricula').value,
    estado: document.getElementById('estado').value
  };

  const divMensaje = document.getElementById('mensaje-camion');

  try {
    const respuesta = await fetch(`${API_URL}/camiones.php`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(datos)
    });

    const resultado = await respuesta.json();

    if (respuesta.ok && resultado.exito) {
      divMensaje.innerHTML = `<div class="mensaje exito">${resultado.mensaje}</div>`;
      document.getElementById('form-camion').reset();
      cargarCamiones();
    } else {
      divMensaje.innerHTML = `<div class="mensaje error">${resultado.mensaje}</div>`;
    }
  } catch (error) {
    divMensaje.innerHTML = `<div class="mensaje error">Error de conexión con el servidor</div>`;
    console.error(error);
  }
});

cargarCamiones();
