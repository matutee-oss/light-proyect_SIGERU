/**
 * panel-admin.js
 * Carga el resumen del sistema y pinta el mapa de contenedores,
 * coloreado según prioridad (rojo = alta / desbordado, ámbar = media
 * / roto, verde = funcional).
 */

const sesion = exigirSesion(['administrador']);

function colorSegunEstado(estado) {
  if (estado === 'desbordado') return '#ad4d38';
  if (estado === 'roto') return '#c97f24';
  return '#1b4b43';
}

function pintarMapa(contenedores) {
  const mapa = L.map('mapa-contenedores').setView([-34.9011, -56.1645], 12);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; OpenStreetMap contributors',
    maxZoom: 18
  }).addTo(mapa);

  contenedores.forEach(function (c) {
    if (!c.latitud || !c.longitud) return;
    const color = colorSegunEstado(c.estado);

    L.circleMarker([c.latitud, c.longitud], {
      radius: 9,
      color: color,
      fillColor: color,
      fillOpacity: 0.85,
      weight: 2
    })
      .addTo(mapa)
      .bindPopup(`<strong>${c.ubicacion}</strong><br>${c.tipo_residuo}<br>Estado: ${c.estado}`);
  });
}

function pintarUsuarios(usuarios) {
  const tabla = document.getElementById('tabla-usuarios');
  tabla.innerHTML = '';

  usuarios.forEach(function (u) {
    const fila = document.createElement('tr');
    fila.innerHTML = `
      <td>${u.nombre} ${u.apellido}</td>
      <td>${u.email}</td>
      <td><span class="mono" style="font-size:12px;">${u.tipo_usuario}</span></td>
      <td><span class="etiqueta-estado estado-${u.estado}">${u.estado}</span></td>
    `;
    tabla.appendChild(fila);
  });
}

async function cargarPanel() {
  const respuesta = await fetchAutenticado(`${API_URL}/panel_admin.php`);
  const datos = await respuesta.json();

  if (!respuesta.ok) {
    document.querySelector('main').innerHTML = `<div class="mensaje error">${datos.mensaje}</div>`;
    return;
  }

  document.getElementById('stat-zonas').textContent = datos.estadisticas.zonas;
  document.getElementById('stat-contenedores').textContent = datos.estadisticas.contenedores;
  document.getElementById('stat-camiones').textContent = datos.estadisticas.camiones;
  document.getElementById('stat-usuarios').textContent = datos.estadisticas.usuarios;
  document.getElementById('stat-incidencias').textContent = datos.estadisticas.incidencias_abiertas;

  pintarMapa(datos.contenedores);
  pintarUsuarios(datos.usuarios);
}

cargarPanel();
