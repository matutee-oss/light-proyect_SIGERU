/**
 * panel-cuadrilla.js
 * Muestra las incidencias asignadas a la cuadrilla autenticada
 * y las que están sin asignar (para poder tomarlas).
 */

const sesion = exigirSesion(['cuadrilla']);

function pintarLista(idContenedor, lista, sonMias) {
  const contenedor = document.getElementById(idContenedor);
  contenedor.innerHTML = '';

  if (lista.length === 0) {
    contenedor.innerHTML = '<p class="mono" style="color:var(--ink-faint); font-size:13px;">Nada por aquí.</p>';
    return;
  }

  lista.forEach(function (i) {
    const item = document.createElement('div');
    item.className = 'tarjeta-item';
    item.innerHTML = `
      <div>
        <strong>${i.contenedor_ubicacion}</strong>
        <div class="mono" style="font-size:12px; color:var(--ink-soft); margin-top:2px;">
          ${i.tipo} · <span class="etiqueta-estado estado-${i.estado}">${i.estado}</span>
        </div>
      </div>
      ${sonMias
        ? `<select data-id="${i.id_incidencia}" class="select-estado">
             <option value="en_curso" ${i.estado === 'en_curso' ? 'selected' : ''}>En curso</option>
             <option value="resuelta" ${i.estado === 'resuelta' ? 'selected' : ''}>Resuelta</option>
           </select>`
        : `<button data-id="${i.id_incidencia}" class="btn-tomar">Tomar</button>`
      }
    `;
    contenedor.appendChild(item);
  });

  contenedor.querySelectorAll('.btn-tomar').forEach(function (boton) {
    boton.addEventListener('click', async function () {
      await fetchAutenticado(`${API_URL}/incidencias.php?id=${boton.dataset.id}&accion=tomar`, { method: 'PUT' });
      cargarPanel();
    });
  });

  contenedor.querySelectorAll('.select-estado').forEach(function (select) {
    select.addEventListener('change', async function () {
      await fetchAutenticado(`${API_URL}/incidencias.php?id=${select.dataset.id}&accion=estado`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ estado: select.value })
      });
      cargarPanel();
    });
  });
}

async function cargarPanel() {
  const respuesta = await fetchAutenticado(`${API_URL}/incidencias.php`);
  const incidencias = await respuesta.json();

  const mias = incidencias.filter(i => i.id_cuadrilla == sesion.usuario.id);
  const disponibles = incidencias.filter(i => !i.id_cuadrilla);

  pintarLista('lista-mias', mias, true);
  pintarLista('lista-disponibles', disponibles, false);
}

cargarPanel();
