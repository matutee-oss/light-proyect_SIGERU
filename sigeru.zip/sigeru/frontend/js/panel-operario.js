/**
 * panel-operario.js
 * Muestra el centro de acopio del operario autenticado (relación
 * "trabaja_en") y permite actualizar la cantidad de sus recursos.
 */

const sesion = exigirSesion(['operario']);

async function cargarPanel() {
  const respuesta = await fetchAutenticado(`${API_URL}/panel_operario.php`);
  const datos = await respuesta.json();

  if (!respuesta.ok) {
    document.getElementById('contenido-operario').innerHTML =
      `<div class="mensaje error">${datos.mensaje}</div>`;
    return;
  }

  document.getElementById('nombre-centro').textContent = datos.centro.nombre;
  document.getElementById('ubicacion-centro').textContent = datos.centro.ubicacion;
  document.getElementById('capacidad-centro').textContent = `${datos.centro.capacidad} m³`;

  const tabla = document.getElementById('tabla-recursos');
  tabla.innerHTML = '';

  datos.recursos.forEach(function (r) {
    const fila = document.createElement('tr');
    fila.innerHTML = `
      <td>${r.tipo}</td>
      <td><input type="number" min="0" value="${r.cantidad}" data-id="${r.id_recurso}" class="input-recurso"></td>
      <td><button data-id="${r.id_recurso}" class="btn-guardar-recurso">Guardar</button></td>
    `;
    tabla.appendChild(fila);
  });

  document.querySelectorAll('.btn-guardar-recurso').forEach(function (boton) {
    boton.addEventListener('click', async function () {
      const id = boton.dataset.id;
      const input = document.querySelector(`.input-recurso[data-id="${id}"]`);

      const respuesta = await fetchAutenticado(`${API_URL}/panel_operario.php?id_recurso=${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cantidad: parseInt(input.value, 10) })
      });

      if (respuesta.ok) {
        boton.textContent = 'Guardado ✓';
        setTimeout(() => { boton.textContent = 'Guardar'; }, 1500);
      }
    });
  });
}

cargarPanel();
