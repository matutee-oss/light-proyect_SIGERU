<?php
/**
 * Controlador del panel de Administrador.
 * Agrega la información que necesita el dashboard: estadísticas
 * generales, el listado de contenedores (con coordenadas, para el
 * mapa) y el listado general de usuarios.
 */

require_once __DIR__ . '/../models/Usuario.php';
require_once __DIR__ . '/../models/Contenedor.php';
require_once __DIR__ . '/../models/Camion.php';
require_once __DIR__ . '/../models/Zona.php';
require_once __DIR__ . '/../models/Incidencia.php';

class AdminController
{
    private Usuario $modeloUsuario;
    private Contenedor $modeloContenedor;
    private Camion $modeloCamion;
    private Zona $modeloZona;
    private Incidencia $modeloIncidencia;

    public function __construct(PDO $conexion)
    {
        $this->modeloUsuario = new Usuario($conexion);
        $this->modeloContenedor = new Contenedor($conexion);
        $this->modeloCamion = new Camion($conexion);
        $this->modeloZona = new Zona($conexion);
        $this->modeloIncidencia = new Incidencia($conexion);
    }

    public function obtenerResumen(): array
    {
        $usuarios = $this->modeloUsuario->listarTodos();
        $contenedores = $this->modeloContenedor->listarTodos();
        $camiones = $this->modeloCamion->listarTodos();
        $zonas = $this->modeloZona->listarTodas();

        return [
            'estadisticas' => [
                'usuarios'            => count($usuarios),
                'contenedores'        => count($contenedores),
                'camiones'            => count($camiones),
                'zonas'               => count($zonas),
                'incidencias_abiertas' => $this->modeloIncidencia->contarAbiertas(),
            ],
            'contenedores' => $contenedores,
            'usuarios'     => $usuarios,
            'zonas'        => $zonas,
        ];
    }
}
