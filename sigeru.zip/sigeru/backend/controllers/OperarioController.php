<?php
/**
 * Controlador del panel de Operario.
 * Resuelve la relación "trabaja_en": muestra el centro de acopio
 * asignado al operario autenticado y sus recursos.
 */

require_once __DIR__ . '/../models/CentroAcopio.php';

class OperarioController
{
    private CentroAcopio $modelo;

    public function __construct(PDO $conexion)
    {
        $this->modelo = new CentroAcopio($conexion);
    }

    public function obtenerPanel(int $idUsuarioOperario): array
    {
        $centro = $this->modelo->buscarPorOperario($idUsuarioOperario);

        if (!$centro) {
            return ['exito' => false, 'mensaje' => 'No tenés un centro de acopio asignado todavía'];
        }

        $recursos = $this->modelo->listarRecursos((int) $centro['id_centro']);

        return ['exito' => true, 'centro' => $centro, 'recursos' => $recursos];
    }

    public function actualizarRecurso(int $idUsuarioOperario, int $idRecurso, int $cantidad): array
    {
        $centro = $this->modelo->buscarPorOperario($idUsuarioOperario);

        if (!$centro) {
            return ['exito' => false, 'mensaje' => 'No tenés un centro de acopio asignado'];
        }

        $this->modelo->actualizarRecurso((int) $centro['id_centro'], $idRecurso, $cantidad);
        return ['exito' => true, 'mensaje' => 'Recurso actualizado'];
    }
}
