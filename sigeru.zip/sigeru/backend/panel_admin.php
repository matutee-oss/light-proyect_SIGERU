<?php
/**
 * Endpoint: GET /panel_admin.php
 * Devuelve el resumen completo del sistema para el dashboard del
 * administrador: estadísticas, contenedores (con coordenadas para
 * el mapa), usuarios y zonas.
 * Requiere header: Authorization: Bearer <token>, rol administrador.
 */

require_once __DIR__ . '/config/cabeceras.php';
require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/helpers/respuesta.php';
require_once __DIR__ . '/helpers/autenticacion.php';
require_once __DIR__ . '/controllers/AdminController.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    responderJson(405, ['mensaje' => 'Método no permitido']);
}

$conexion = obtenerConexion();
$usuarioAutenticado = requerirUsuario($conexion);
requerirRol($usuarioAutenticado, ['administrador']);

$controlador = new AdminController($conexion);
responderJson(200, $controlador->obtenerResumen());
