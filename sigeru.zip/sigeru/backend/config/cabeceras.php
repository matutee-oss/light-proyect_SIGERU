<?php
/**
 * Cabeceras comunes para todos los endpoints de la API.
 * Habilita CORS para que el Frontend (otro origen) pueda consumir la API.
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Responder rápido a las peticiones "preflight" del navegador
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}
