<?php

require_once __DIR__ . '/config/cabeceras.php';
require_once __DIR__ . '/config/conexion.php';
require_once __DIR__ . '/helpers/respuesta.php';
require_once __DIR__ . '/helpers/autenticacion.php';
require_once __DIR__ . '/controllers/IncidenciaController.php';

$conexion = obtenerConexion();
$usuarioAutenticado = requerirUsuario($conexion);
$controlador = new IncidenciaController($conexion);

switch ($_SERVER['REQUEST_METHOD']) {
    case 'GET':
        responderJson(200, $controlador->listarSegunRol($usuarioAutenticado));
        break;

    case 'POST':
        requerirRol($usuarioAutenticado, ['vecino']);
        $datos = leerCuerpoJson();
        $resultado = $controlador->reportar((int) $usuarioAutenticado['id_usuario'], $datos);
        responderJson($resultado['exito'] ? 201 : 400, $resultado);
        break;

    case 'PUT':
        requerirRol($usuarioAutenticado, ['cuadrilla', 'administrador']);
        $id = isset($_GET['id']) ? (int) $_GET['id'] : null;
        $accion = $_GET['accion'] ?? null;

        if (!$id || !$accion) {
            responderJson(400, ['mensaje' => 'Debe indicar ?id= y ?accion=']);
        }

        if ($accion === 'tomar') {
            $resultado = $controlador->tomar($id, $usuarioAutenticado);
        } elseif ($accion === 'estado') {
            $datos = leerCuerpoJson();
            $resultado = $controlador->cambiarEstado($id, $datos['estado'] ?? '');
        } else {
            responderJson(400, ['mensaje' => 'Acción no reconocida']);
        }

        responderJson($resultado['exito'] ? 200 : 400, $resultado);
        break;

    default:
        responderJson(405, ['mensaje' => 'Método no permitido']);
}
