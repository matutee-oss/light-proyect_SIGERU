<?php
/**
 * Modelo CodigoFuncionario.
 * Valida y consume los códigos de un solo uso que habilitan el registro
 * como administrador, cuadrilla u operario (roles internos del sistema).
 */

class CodigoFuncionario
{
    private PDO $conexion;

    public function __construct(PDO $conexion)
    {
        $this->conexion = $conexion;
    }

    /**
     * Busca el código con bloqueo de fila (FOR UPDATE), para usarse
     * siempre dentro de una transacción y evitar que dos registros
     * simultáneos consuman el mismo código.
     */
    public function buscarParaConsumir(string $codigo, string $tipoUsuario): ?array
    {
        $consulta = $this->conexion->prepare(
            'SELECT * FROM codigos_funcionario
             WHERE codigo = :codigo AND tipo_usuario = :tipo_usuario
             FOR UPDATE'
        );
        $consulta->execute([
            'codigo'       => $codigo,
            'tipo_usuario' => $tipoUsuario,
        ]);
        $resultado = $consulta->fetch();
        return $resultado ?: null;
    }

    public function marcarUsado(int $idCodigo, int $idUsuario): bool
    {
        $consulta = $this->conexion->prepare(
            'UPDATE codigos_funcionario
             SET usado = TRUE, id_usuario = :id_usuario
             WHERE id_codigo = :id_codigo'
        );
        return $consulta->execute([
            'id_usuario' => $idUsuario,
            'id_codigo'  => $idCodigo,
        ]);
    }
}
