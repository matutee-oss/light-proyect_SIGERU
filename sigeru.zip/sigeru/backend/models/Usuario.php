<?php
/**
 * Modelo Usuario.
 * Refleja la especialización total/disjunta del MER: la tabla "usuarios"
 * contiene los atributos comunes, y cada subtipo (administradores,
 * cuadrillas, operarios, vecinos) tiene su propia tabla 1 a 1.
 */

class Usuario
{
    private PDO $conexion;

    public function __construct(PDO $conexion)
    {
        $this->conexion = $conexion;
    }

    public function buscarPorEmail(string $email): ?array
    {
        $consulta = $this->conexion->prepare(
            'SELECT * FROM usuarios WHERE email = :email'
        );
        $consulta->execute(['email' => $email]);
        $resultado = $consulta->fetch();
        return $resultado ?: null;
    }

    public function buscarPorId(int $idUsuario): ?array
    {
        $consulta = $this->conexion->prepare('SELECT * FROM usuarios WHERE id_usuario = :id');
        $consulta->execute(['id' => $idUsuario]);
        $resultado = $consulta->fetch();
        return $resultado ?: null;
    }

    public function actualizarPerfil(int $idUsuario, array $datos): bool
    {
        $consulta = $this->conexion->prepare(
            'UPDATE usuarios SET nombre = :nombre, apellido = :apellido, telefono = :telefono
             WHERE id_usuario = :id_usuario'
        );
        return $consulta->execute([
            'nombre'     => $datos['nombre'],
            'apellido'   => $datos['apellido'],
            'telefono'   => $datos['telefono'] ?? null,
            'id_usuario' => $idUsuario,
        ]);
    }

    public function actualizarFoto(int $idUsuario, string $rutaFoto): bool
    {
        $consulta = $this->conexion->prepare(
            'UPDATE usuarios SET foto = :foto WHERE id_usuario = :id_usuario'
        );
        return $consulta->execute(['foto' => $rutaFoto, 'id_usuario' => $idUsuario]);
    }

    public function listarTodos(): array
    {
        $consulta = $this->conexion->query(
            'SELECT id_usuario, nombre, apellido, ci, email, tipo_usuario, estado
             FROM usuarios
             ORDER BY id_usuario DESC'
        );
        return $consulta->fetchAll();
    }

    /**
     * Crea el usuario base y su fila en la tabla del subtipo correspondiente.
     * No maneja su propia transacción: el llamador (AuthController) la
     * controla, porque también debe coordinar el consumo del código
     * de funcionario dentro de la misma transacción.
     */
    public function crear(array $datos): int
    {
        $consulta = $this->conexion->prepare(
            'INSERT INTO usuarios (nombre, apellido, ci, telefono, email, password_hash, tipo_usuario, estado)
             VALUES (:nombre, :apellido, :ci, :telefono, :email, :password_hash, :tipo_usuario, :estado)'
        );
        $consulta->execute([
            'nombre'        => $datos['nombre'],
            'apellido'      => $datos['apellido'],
            'ci'            => $datos['ci'],
            'telefono'      => $datos['telefono'] ?? null,
            'email'         => $datos['email'],
            'password_hash' => $datos['password_hash'],
            'tipo_usuario'  => $datos['tipo_usuario'],
            'estado'        => 'pendiente',
        ]);

        $idUsuario = (int) $this->conexion->lastInsertId();
        $tablaSubtipo = $this->tablaSegunTipo($datos['tipo_usuario']);

        if ($tablaSubtipo === 'operarios') {
            // Operario requiere el centro de acopio donde trabaja (trabaja_en)
            $sub = $this->conexion->prepare(
                'INSERT INTO operarios (id_usuario, id_centro) VALUES (:id_usuario, :id_centro)'
            );
            $sub->execute([
                'id_usuario' => $idUsuario,
                'id_centro'  => $datos['id_centro'] ?? null,
            ]);
        } else {
            $sub = $this->conexion->prepare(
                "INSERT INTO {$tablaSubtipo} (id_usuario) VALUES (:id_usuario)"
            );
            $sub->execute(['id_usuario' => $idUsuario]);
        }

        return $idUsuario;
    }

    public function actualizarEstado(int $idUsuario, string $estado): bool
    {
        $consulta = $this->conexion->prepare(
            'UPDATE usuarios SET estado = :estado WHERE id_usuario = :id_usuario'
        );
        return $consulta->execute(['estado' => $estado, 'id_usuario' => $idUsuario]);
    }

    public function listarPendientes(): array
    {
        $consulta = $this->conexion->query(
            "SELECT id_usuario, nombre, apellido, ci, email, tipo_usuario, creado_en
             FROM usuarios
             WHERE estado = 'pendiente'
             ORDER BY creado_en DESC"
        );
        return $consulta->fetchAll();
    }

    public function obtenerZonaVecino(int $idUsuario): ?int
    {
        $consulta = $this->conexion->prepare(
            'SELECT id_zona FROM vecinos WHERE id_usuario = :id'
        );
        $consulta->execute(['id' => $idUsuario]);
        $zona = $consulta->fetchColumn();
        return $zona ? (int) $zona : null;
    }

    public function asignarZonaVecino(int $idUsuario, int $idZona): bool
    {
        $consulta = $this->conexion->prepare(
            'UPDATE vecinos SET id_zona = :id_zona WHERE id_usuario = :id'
        );
        return $consulta->execute(['id_zona' => $idZona, 'id' => $idUsuario]);
    }

    private function tablaSegunTipo(string $tipoUsuario): string
    {
        $mapa = [
            'administrador' => 'administradores',
            'cuadrilla'     => 'cuadrillas',
            'operario'      => 'operarios',
            'vecino'        => 'vecinos',
        ];

        if (!isset($mapa[$tipoUsuario])) {
            throw new InvalidArgumentException('tipo_usuario inválido');
        }

        return $mapa[$tipoUsuario];
    }
}
