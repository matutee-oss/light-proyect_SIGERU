<?php
/**
 * Modelo Camion.
 * Según el MER, Camion solo tiene los atributos matricula y estado.
 */

class Camion
{
    private PDO $conexion;

    public function __construct(PDO $conexion)
    {
        $this->conexion = $conexion;
    }

    public function listarTodos(): array
    {
        $consulta = $this->conexion->query('SELECT * FROM camiones ORDER BY id_camion DESC');
        return $consulta->fetchAll();
    }

    public function buscarPorId(int $id): ?array
    {
        $consulta = $this->conexion->prepare('SELECT * FROM camiones WHERE id_camion = :id');
        $consulta->execute(['id' => $id]);
        $resultado = $consulta->fetch();
        return $resultado ?: null;
    }

    public function crear(array $datos): int
    {
        $consulta = $this->conexion->prepare(
            'INSERT INTO camiones (matricula, estado) VALUES (:matricula, :estado)'
        );
        $consulta->execute([
            'matricula' => $datos['matricula'],
            'estado'    => $datos['estado'] ?? 'disponible',
        ]);
        return (int) $this->conexion->lastInsertId();
    }

    public function actualizar(int $id, array $datos): bool
    {
        $consulta = $this->conexion->prepare(
            'UPDATE camiones SET matricula = :matricula, estado = :estado WHERE id_camion = :id'
        );
        return $consulta->execute([
            'matricula' => $datos['matricula'],
            'estado'    => $datos['estado'],
            'id'        => $id,
        ]);
    }

    public function eliminar(int $id): bool
    {
        $consulta = $this->conexion->prepare('DELETE FROM camiones WHERE id_camion = :id');
        return $consulta->execute(['id' => $id]);
    }
}
