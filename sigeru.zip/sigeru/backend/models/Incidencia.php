<?php
/**
 * Modelo Incidencia.
 * Cubre las relaciones "genera" (Contenedor), "Reporta" (Vecino)
 * y "atiende" (Cuadrilla) del MER.
 */

class Incidencia
{
    private PDO $conexion;

    public function __construct(PDO $conexion)
    {
        $this->conexion = $conexion;
    }

    private const SELECT_BASE = "
        SELECT i.*, c.ubicacion AS contenedor_ubicacion, c.estado AS contenedor_estado,
               uv.nombre AS vecino_nombre, uv.apellido AS vecino_apellido,
               uc.nombre AS cuadrilla_nombre, uc.apellido AS cuadrilla_apellido
        FROM incidencias i
        JOIN contenedores c ON c.id_contenedor = i.id_contenedor
        LEFT JOIN usuarios uv ON uv.id_usuario = i.id_vecino
        LEFT JOIN usuarios uc ON uc.id_usuario = i.id_cuadrilla
    ";

    public function contarAbiertas(): int
    {
        $consulta = $this->conexion->query(
            "SELECT COUNT(*) AS total FROM incidencias WHERE estado != 'resuelta'"
        );
        return (int) $consulta->fetch()['total'];
    }

    public function crear(int $idContenedor, string $tipo, int $idVecino): int
    {
        $consulta = $this->conexion->prepare(
            'INSERT INTO incidencias (tipo, id_contenedor, id_vecino) VALUES (:tipo, :id_contenedor, :id_vecino)'
        );
        $consulta->execute([
            'tipo'          => $tipo,
            'id_contenedor' => $idContenedor,
            'id_vecino'     => $idVecino,
        ]);
        return (int) $this->conexion->lastInsertId();
    }

    public function listarTodas(): array
    {
        $consulta = $this->conexion->query(self::SELECT_BASE . ' ORDER BY i.fecha_apertura DESC');
        return $consulta->fetchAll();
    }

    public function listarPorVecino(int $idVecino): array
    {
        $consulta = $this->conexion->prepare(
            self::SELECT_BASE . ' WHERE i.id_vecino = :id ORDER BY i.fecha_apertura DESC'
        );
        $consulta->execute(['id' => $idVecino]);
        return $consulta->fetchAll();
    }

    /**
     * Para la cuadrilla: sus incidencias asignadas + las abiertas sin asignar
     * todavía (para que puedan tomarlas).
     */
    public function listarParaCuadrilla(int $idCuadrilla): array
    {
        $consulta = $this->conexion->prepare(
            self::SELECT_BASE . '
             WHERE i.id_cuadrilla = :id OR (i.id_cuadrilla IS NULL AND i.estado = "abierta")
             ORDER BY i.fecha_apertura ASC'
        );
        $consulta->execute(['id' => $idCuadrilla]);
        return $consulta->fetchAll();
    }

    public function buscarPorId(int $id): ?array
    {
        $consulta = $this->conexion->prepare(self::SELECT_BASE . ' WHERE i.id_incidencia = :id');
        $consulta->execute(['id' => $id]);
        $resultado = $consulta->fetch();
        return $resultado ?: null;
    }

    public function asignarCuadrilla(int $idIncidencia, int $idCuadrilla): bool
    {
        $consulta = $this->conexion->prepare(
            'UPDATE incidencias SET id_cuadrilla = :id_cuadrilla, estado = "en_curso"
             WHERE id_incidencia = :id'
        );
        return $consulta->execute(['id_cuadrilla' => $idCuadrilla, 'id' => $idIncidencia]);
    }

    public function actualizarEstado(int $idIncidencia, string $estado): bool
    {
        $fechaResolucion = $estado === 'resuelta' ? 'NOW()' : 'NULL';
        $consulta = $this->conexion->prepare(
            "UPDATE incidencias SET estado = :estado, fecha_resolucion = {$fechaResolucion}
             WHERE id_incidencia = :id"
        );
        return $consulta->execute(['estado' => $estado, 'id' => $idIncidencia]);
    }
}
