<?php
/**
 * Modelo CentroAcopio.
 * Incluye la consulta que resuelve la relación "trabaja_en" con Operario.
 */

class CentroAcopio
{
    private PDO $conexion;

    public function __construct(PDO $conexion)
    {
        $this->conexion = $conexion;
    }

    public function buscarPorOperario(int $idUsuarioOperario): ?array
    {
        $consulta = $this->conexion->prepare(
            'SELECT ca.*
             FROM centros_acopio ca
             JOIN operarios o ON o.id_centro = ca.id_centro
             WHERE o.id_usuario = :id_usuario'
        );
        $consulta->execute(['id_usuario' => $idUsuarioOperario]);
        $resultado = $consulta->fetch();
        return $resultado ?: null;
    }

    public function listarRecursos(int $idCentro): array
    {
        $consulta = $this->conexion->prepare(
            'SELECT * FROM recursos WHERE id_centro = :id_centro ORDER BY tipo'
        );
        $consulta->execute(['id_centro' => $idCentro]);
        return $consulta->fetchAll();
    }

    public function actualizarRecurso(int $idCentro, int $idRecurso, int $cantidad): bool
    {
        $consulta = $this->conexion->prepare(
            'UPDATE recursos SET cantidad = :cantidad
             WHERE id_centro = :id_centro AND id_recurso = :id_recurso'
        );
        return $consulta->execute([
            'cantidad'   => $cantidad,
            'id_centro'  => $idCentro,
            'id_recurso' => $idRecurso,
        ]);
    }
}
