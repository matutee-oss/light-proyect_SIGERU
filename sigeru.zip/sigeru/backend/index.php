<?php

require_once __DIR__ . '/config/cabeceras.php';
require_once __DIR__ . '/helpers/respuesta.php';

responderJson(200, [
    'sistema'   => 'SiGeRU - API de Gestión de Residuos Urbanos',
    'version'   => '1.0',
    'endpoints' => [
        'POST /login.php'             => 'Iniciar sesión',
        'POST /registro.php'          => 'Registrar nuevo usuario (queda pendiente de aprobación)',
        'GET/POST/PUT/DELETE /contenedores.php' => 'ABM de contenedores',
        'GET/POST/PUT/DELETE /camiones.php'     => 'ABM de camiones (flota)',
    ],
]);
